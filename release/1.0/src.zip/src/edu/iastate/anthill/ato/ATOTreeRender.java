package edu.iastate.anthill.ato;

import edu.iastate.anthill.indus.IndusConstants;
import edu.iastate.anthill.indus.tree.TypedTreeRender;

/**
 * Animal Trait Ontology Tree Render
 * @author Jie Bao
 * @since 2005-04-22
 */
public class ATOTreeRender
    extends TypedTreeRender
{
    public ATOTreeRender()
    {
        super();
        icons.put(AtoOntology.TRAIT + "", IndusConstants.iconAtoTrait);
        icons.put(AtoOntology.CLASS + "", IndusConstants.iconAtoClass);
        icons.put(AtoOntology.TYPE + "", IndusConstants.iconAtoType);
        icons.put(AtoOntology.SPECIES + "", IndusConstants.iconAtoSpecies);
        icons.put(AtoOntology.ROOT + "", IndusConstants.iconRoot);
    }
}

package edu.iastate.anthill.ato;

import edu.iastate.anthill.indus.iterator.DBTreeNode;
import java.awt.Color;
import java.util.*;

/**
 * @author Jie Bao
 * @since 1.0 2005-04-23
 */
public class ATOTreeNode
    extends DBTreeNode
{
    static public final short UNMODIFIED = 0;
    static public final short MODIFIED = 1;
    static public final short DELETED = 2;

    public short status = UNMODIFIED;

    public ATOTreeNode(String id, String externalText, short type)
    {
        super(id, externalText);
        this.comment = externalText;
        setType(type);
    }

    public Color getColor()
    {
        Map<Short, Color> m= new HashMap();
        m.put(UNMODIFIED, Color.black);
        m.put(MODIFIED, Color.red);
        m.put(DELETED, Color.lightGray);

        color = m.get(status);
        return color;
    }

}

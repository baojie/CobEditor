package edu.iastate.anthill.ato;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.KeyEvent;
import javax.swing.Icon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JToolBar;
import javax.swing.KeyStroke;
import javax.swing.ToolTipManager;

import edu.iastate.utils.gui.GUIUtils;
import edu.iastate.utils.gui.JStatusBar;

/**
 * @author Jie Bao
 * @since 2005-04-20
 */
public class ATOEditorGUI
    extends JPanel
{

    public ATOEditorGUI()
    {
        super();
        try
        {
            jbInit();
        }
        catch (Exception ex)
        {
            ex.printStackTrace();
        }
    }

    Icon redoIcon = GUIUtils.loadIcon("images/redo.gif");
    Icon undoIcon = GUIUtils.loadIcon("images/undo.gif");
    Icon submitIcon = GUIUtils.loadIcon("images/save.gif");
    Icon configIcon = GUIUtils.loadIcon("images/config.gif");
    Icon aboutIcon = GUIUtils.loadIcon("images/about.gif");
    Icon expandIcon = GUIUtils.loadIcon("images/expand.gif");
    Icon expandAllIcon = GUIUtils.loadIcon("images/expandall.gif");
    Icon helpIcon = GUIUtils.loadIcon("images/help.gif");
    Icon hogIcon = GUIUtils.loadIcon("images/hog.jpg");
    Icon reloadIcon = GUIUtils.loadIcon("images/reload.gif");
    Icon searchIcon = GUIUtils.loadIcon("images/search.gif");
    Icon findnextIcon = GUIUtils.loadIcon("images/findnext.gif");

    private void jbInit() throws Exception
    {
        // Show tool tips immediately
        ToolTipManager.sharedInstance().setInitialDelay(0);

        this.setLayout(borderLayout1);
        btnUndo.setToolTipText("Undo");
        btnUndo.setIcon(undoIcon);
        btnRedo.setToolTipText("Redo");
        btnRedo.setIcon(redoIcon);
        btnSubmit.setToolTipText("Submit Change");
        btnSubmit.setIcon(submitIcon);
        btnConfig.setToolTipText("Settings");
        btnConfig.setIcon(configIcon);
        btnAbout.setToolTipText("About");
        btnAbout.setIcon(aboutIcon);
        btnExpand.setToolTipText("Expand");
        btnExpand.setIcon(expandIcon);
        btnHelp.setToolTipText("Help");
        btnHelp.setIcon(helpIcon);
        btnReload.setToolTipText("Reload");
        btnReload.setIcon(reloadIcon);
        btnFind.setToolTipText("Find (F3 to repeat last search)");
        btnFind.setIcon(searchIcon);

        jSplitPane1.setOrientation(JSplitPane.HORIZONTAL_SPLIT);
        paneDetails.setLayout(borderLayout2);
        jmenuEdit.setText("Edit");
        menuFindNext.setIcon(findnextIcon);
        menuFindNext.setText("Find Next");
        menuFindNext.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_F3, 0, false));
        menuFind.setText("Find");
        menuFind.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.
            event.KeyEvent.VK_F3, java.awt.event.KeyEvent.CTRL_MASK, false));
        menuFind.setIcon(searchIcon);
        menuUndo.setIcon(undoIcon);
        menuUndo.setText("Undo");
        menuUndo.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.
            event.KeyEvent.VK_Z, java.awt.event.KeyEvent.CTRL_MASK, false));
        menuRedo.setIcon(redoIcon);
        menuRedo.setText("Redo");
        menuRedo.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.
            event.KeyEvent.VK_R, java.awt.event.KeyEvent.CTRL_MASK, false));
        jToolBar1.setOrientation(JToolBar.VERTICAL);
        jmenuHelp.setText("Help");
        menuHelp.setIcon(helpIcon);
        menuHelp.setText("Help...");
        menuHelp.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.
            event.KeyEvent.VK_F1, 0, false));
        menuAbout.setIcon(aboutIcon);
        menuAbout.setText("About...");
        menuExpand.setIcon(expandIcon);
        menuExpand.setText("Expand");
        menuExpand.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.
            event.KeyEvent.VK_E, java.awt.event.KeyEvent.CTRL_MASK, false));
        menuExpandAll.setIcon(expandAllIcon);
        menuExpandAll.setText("Expand All");
        menuExpandAll.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.
            event.KeyEvent.VK_A, java.awt.event.KeyEvent.CTRL_MASK, false));

        jToolBar1.add(btnExpand);
        jToolBar1.add(btnFind);
        jToolBar1.add(btnUndo);
        jToolBar1.add(btnRedo);
        jToolBar1.add(btnReload);
        jToolBar1.add(btnSubmit);
        jToolBar1.add(btnConfig);
        jToolBar1.add(btnHelp);
        jToolBar1.add(btnAbout);
        this.add(statusBar, java.awt.BorderLayout.SOUTH);
        this.add(jSplitPane1, java.awt.BorderLayout.CENTER);
        jSplitPane1.add(paneTree, JSplitPane.TOP);
        jSplitPane1.add(paneDetails, JSplitPane.BOTTOM);
        jMenuBar1.add(jmenuEdit);
        jMenuBar1.add(jmenuHelp);
        jmenuEdit.add(menuExpand);
        jmenuEdit.add(menuExpandAll);
        jmenuEdit.addSeparator();
        jmenuEdit.add(menuFind);
        jmenuEdit.add(menuFindNext);
        jmenuEdit.addSeparator();
        jmenuEdit.add(menuUndo);
        jmenuEdit.add(menuRedo);
        this.add(jToolBar1, java.awt.BorderLayout.WEST);
        jmenuHelp.add(menuHelp);
        jmenuHelp.add(menuAbout);
        mainFrame.setJMenuBar(jMenuBar1);
    }

    public JFrame mainFrame = new JFrame();

    JScrollPane paneTree = new JScrollPane();
    BorderLayout borderLayout1 = new BorderLayout();
    JToolBar jToolBar1 = new JToolBar();
    JButton btnUndo = new JButton();
    JButton btnRedo = new JButton();
    JButton btnConfig = new JButton();
    JButton btnSubmit = new JButton();
    JButton btnReload = new JButton();
    JButton btnFind = new JButton();
    JStatusBar statusBar = new JStatusBar(
        "Double click a node to expand, right click on node to see menu");
    GridLayout gridLayout1 = new GridLayout();
    JButton btnAbout = new JButton();
    JSplitPane jSplitPane1 = new JSplitPane();
    JPanel paneDetails = new JPanel();
    BorderLayout borderLayout2 = new BorderLayout();
    JButton btnExpand = new JButton();
    JButton btnHelp = new JButton();
    JMenuBar jMenuBar1 = new JMenuBar();
    JMenu jmenuEdit = new JMenu();
    JMenuItem menuFindNext = new JMenuItem();
    JMenuItem menuFind = new JMenuItem();
    JMenuItem menuUndo = new JMenuItem();
    JMenuItem menuRedo = new JMenuItem();
    JMenu jmenuHelp = new JMenu();
    JMenuItem menuHelp = new JMenuItem();
    JMenuItem menuAbout = new JMenuItem();
    JMenuItem menuExpand = new JMenuItem();
    JMenuItem menuExpandAll = new JMenuItem();
}

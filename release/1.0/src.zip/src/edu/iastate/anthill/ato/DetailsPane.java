package edu.iastate.anthill.ato;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import javax.swing.Icon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import edu.iastate.anthill.indus.IndusConstants;
import edu.iastate.anthill.indus.tree.TypedNode;

import edu.iastate.utils.gui.LabelledItemPanel;
import edu.iastate.utils.lang.MessageHandler;
import edu.iastate.utils.lang.MessageMap;
import java.util.*;

/**
 *
 *
 * @author Jie Bao
 * @since 2005-04-22
 */

//2005-04-23
public class DetailsPane
    extends JPanel implements MessageHandler
{
    ATOTreeNode selectedNode;
    AtoOntology ato;

    // common text field
    JTextField textID = new JTextField();
    JTextField textName = new JTextField();
    JTextField textDomain = new JTextField();
    JTextField textKids = new JTextField();

    // text field used on trait
    JTextField textAbbr = new JTextField();
    JTextField textCustomName = new JTextField();
    JTextField textTraitDesc = new JTextField();
    JTextField textMeasurement = new JTextField();
    JTextField textScaleUnit = new JTextField();

    // BUTTONS
    JButton btnConfirm = new JButton("Confirm");
    JButton btnCancel = new JButton("Cancel");

    LabelledItemPanel mainPane = new LabelledItemPanel();
    JPanel paneButton = new JPanel();
    BorderLayout borderLayout1 = new BorderLayout();

    public DetailsPane(ATOTreeNode node, AtoOntology ato)
    {
        this.selectedNode = node;
        this.ato = ato;
        jbInit();
    }

    public String getString(Object obj)
    {
        return (obj == null) ? null : obj.toString();
    }

    public void updatePane(ATOTreeNode selectedNode)
    {
        String id = getString(selectedNode.getUserObject());
        textID.setText(id);
        String name = getString(selectedNode.getComment());
        textName.setText(name);

        short type = selectedNode.getType();
        String typeStr = AtoOntology.getDomainStr(type);
        textDomain.setText(typeStr);

        // number of children
        ATO2Tree db2tree = (ATO2Tree) ato.templateTree;
        Vector v = db2tree.getChildren(id);
        textKids.setText(v.size() + "");

        if (selectedNode.getType() == AtoOntology.TRAIT)
        {
            Trait trait = db2tree.getTraitDetails(id);
            textAbbr.setText(trait.abbr);
            textCustomName.setText(trait.customName);
            textTraitDesc.setText(trait.traitDesc);
            textMeasurement.setText(trait.measurement);
            textScaleUnit.setText(trait.scaleUnit);
        }

        boolean notDeleted = (selectedNode.status != ATOTreeNode.DELETED);

        textName.setEditable(notDeleted);
        textAbbr.setEditable(notDeleted);
        textCustomName.setEditable(notDeleted);
        textTraitDesc.setEditable(notDeleted);
        textMeasurement.setEditable(notDeleted);
        textScaleUnit.setEditable(notDeleted);

    }

    private void jbInit()
    {
        messageMap();
        textDomain.setEditable(false);
        textID.setEditable(false);
        textKids.setEditable(false);

        Icon icon = ATOTreeRender.icons.get(selectedNode.getType() + "");
        if (icon != null)
        {
            mainPane.addItem("", new JLabel(icon));
        }

        mainPane.addItem("ID", textID);
        mainPane.addItem("Name", textName);
        mainPane.addItem("Domain", textDomain);
        mainPane.addItem("Children(Saved)", textKids);

        // trait details
        if (selectedNode.getType() == AtoOntology.TRAIT)
        {
            mainPane.addItem("Abbreviat", textAbbr);
            mainPane.addItem("Custom Name", textCustomName);
            mainPane.addItem("Trait Description", textTraitDesc);
            mainPane.addItem("Mesaurement", textMeasurement);
            mainPane.addItem("Scale Unit", textScaleUnit);
        }

        updatePane(selectedNode);
        this.setLayout(borderLayout1);

        btnConfirm.setIcon(IndusConstants.iconOK);
        paneButton.add(btnConfirm);
        btnCancel.setIcon(IndusConstants.iconCancel);
        paneButton.add(btnCancel);

        this.add(mainPane, java.awt.BorderLayout.CENTER);
        this.add(paneButton, java.awt.BorderLayout.SOUTH);
    }

    public void messageMap()
    {
        try
        {
            MessageMap.mapAction(this.btnConfirm, this, "onConfirm");
            MessageMap.mapAction(this.btnCancel, this, "onCancel");
        }
        catch (Exception ex)
        {
        }
    }

    public void onConfirm(ActionEvent e)
    {
        String name = textName.getText();
        selectedNode.setComment(name);
        ato.getTreeAVH().getModel().reload(selectedNode);
        selectedNode.status = ATOTreeNode.MODIFIED;

        if (selectedNode.getType() == AtoOntology.TRAIT)
        {
            Tree2ATO tree2db = ATOEditor.tree2db;
            Trait trait = new Trait();
            trait.id = textID.getText();
            trait.name = textName.getText();
            trait.abbr = textAbbr.getText();
            trait.customName = textCustomName.getText();
            trait.traitDesc = textTraitDesc.getText();
            trait.measurement = textMeasurement.getText();
            trait.scaleUnit = textScaleUnit.getText();
            tree2db.saveTrait(trait);
        }
    }

    public void onCancel(ActionEvent e)
    {
        updatePane(selectedNode);
    }
}

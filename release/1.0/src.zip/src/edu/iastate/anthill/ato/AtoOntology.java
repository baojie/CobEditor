package edu.iastate.anthill.ato;

import java.util.HashMap;
import java.util.Map;

import edu.iastate.anthill.indus.datasource.type.DbAVH;
import edu.iastate.anthill.indus.iterator.DB2Tree;
import edu.iastate.anthill.indus.tree.TypedTree;
import edu.iastate.anthill.indus.tree.*;
import java.util.*;

/**
 * Animal Trait Ontology Tree
 * @author Jie Bao
 * @since 2005-04-22
 */
public class AtoOntology
    extends DbAVH
{
    public final static short ROOT = 1000;
    public final static short SPECIES = 1001;
    public final static short CLASS = 1002;
    public final static short TYPE = 1003;
    public final static short TRAIT = 1004;

    public final static String ROOT_STR = "root";
    public final static String TRAIT_STR = "trait";
    public final static String TYPE_STR = "type";
    public final static String CLASS_STR = "class";
    public final static String SPECIES_STR = "species";

    // 2005-04-22
    static short getDomain(String str)
    {
        if (str == null)
        {
            return -1;
        }

        str = str.trim();
        if (ROOT_STR.equals(str))
        {
            return ROOT;
        }
        else if (TRAIT_STR.equals(str))
        {
            return TRAIT;
        }
        else if (TYPE_STR.equals(str))
        {
            return TYPE;
        }
        else if (CLASS_STR.equals(str))
        {
            return CLASS;
        }
        else if (SPECIES_STR.equals(str))
        {
            return SPECIES;
        }

        return -1;
    }

    static String getDomainStr(short type)
    {
        Map<Short, String> m = new HashMap();
        m.put(ROOT, ROOT_STR);
        m.put(SPECIES, SPECIES_STR);
        m.put(CLASS, CLASS_STR);
        m.put(TYPE, TYPE_STR);
        m.put(TRAIT, TRAIT_STR);
        return m.get(type);
    }

    static short getNextLevelDomain(short level)
    {
        if (level == ROOT)
        {
            return SPECIES;
        }
        else if (TRAIT == level)
        {
            return TRAIT;
        }
        else if (TYPE == level)
        {
            return TRAIT;
        }
        else if (CLASS == level)
        {
            return TYPE;
        }
        else if (SPECIES == level)
        {
            return CLASS;
        }
        return -1;
    }

    public AtoOntology(String name, DB2Tree db2tree)
    {
        super(name, "isa", "ato", db2tree);
    }

    public void buildEditor()
    {
        editor = new ATOTreeEditor(this,null);
    }

    public void buildRender()
    {
        render = new ATOTreeRender();
    }

    public void purgeDeleted()
    {
       ATOTreeNode node =  (ATOTreeNode)this.getTreeAVH().getTop();
       Enumeration<ATOTreeNode> en =node.preorderEnumeration();
       while(en.hasMoreElements())
       {
           node = en.nextElement();
           if (node.status == node.DELETED)
           {
               this.getTreeAVH().getModel().removeNodeFromParent(node);
           }
       }


    }
}

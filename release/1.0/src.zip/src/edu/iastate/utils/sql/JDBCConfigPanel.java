package edu.iastate.utils.sql;

import java.util.HashMap;
import java.util.Map;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

import edu.iastate.utils.gui.LabelledItemPanel;

/**
 * A JDBC configuration panel
 *
 * @author Jie Bao
 * @since 2005-04-20
 */
public class JDBCConfigPanel
    extends JPanel
{
    public JDBCConfigPanel()
    {
        try
        {
            //jbInit();
        }
        catch (Exception ex)
        {
            ex.printStackTrace();
        }
    }

    protected JTextField DBMachineURL = new JTextField(),
        jdbcDriver = new JTextField(),
        UserID = new JTextField();
    protected JPasswordField UserPwd = new JPasswordField();
    protected BorderLayout borderLayout1 = new BorderLayout();
    protected JButton btnTest = new JButton("Test Connection");

    protected String[] items =
        {
        "ORACLE", "MYSQL", "POSTGRE"};
    protected JComboBox DBType = new JComboBox(items);

    protected JPanel paneButton = new JPanel();
    protected LabelledItemPanel myContentPane = new LabelledItemPanel();

    // 2005-03-27
    class DbTypeListListener
        implements ItemListener
    {
        Map dbType2URL = new HashMap();
        Map dbType2Driver = new HashMap();

        DbTypeListListener()
        {
            dbType2URL.put("ORACLE", "jdbc:oracle:thin:@host:1521:YOUR_DB_NAME");
            dbType2Driver.put("ORACLE", "oracle.jdbc.driver.OracleDriver");
            dbType2URL.put("POSTGRE",
                           "jdbc:postgresql://host:5432/YOUR_DB_NAME");
            dbType2Driver.put("POSTGRE", "org.postgresql.Driver");
            dbType2URL.put("MYSQL", "jdbc:mysql://host:3306/YOUR_DB_NAME");
            dbType2Driver.put("MYSQL", "org.gjt.mm.mysql.Driver");
        }

        // This method is called only if a new item has been selected.
        public void itemStateChanged(ItemEvent evt)
        {
            // Get the affected item
            Object item = evt.getItem();

            if (evt.getStateChange() == ItemEvent.SELECTED)
            {
                String dbType = (String) DBType.getSelectedItem();

                if (dbType == null)
                {
                    return;
                }

                if (DBMachineURL.getText() == null ||
                    DBMachineURL.getText().trim().length() == 0 ||
                    DBMachineURL.getText().endsWith("YOUR_DB_NAME"))
                {
                    DBMachineURL.setText( (String) dbType2URL.get(dbType));
                }
                jdbcDriver.setText( (String) dbType2Driver.get(dbType));
            }
        }
    }

    /**
     * Test if the given data source is connectable
     * @param evt ActionEvent
     * @since 2005-03-27
     */
    public void onTest(ActionEvent evt)
    {
        LocalDBConnection ds = new LocalDBConnection();

        ds.setUrl(DBMachineURL.getText());
        ds.setUser(UserID.getText());
        ds.setPassword(new String(UserPwd.getPassword()));
        ds.setDriver(jdbcDriver.getText());

        String good = "Given data source is connectable";
        String bad = "Given data source is NOT connectable";
        String info = ds.connect() ? good : bad;
        JOptionPane.showMessageDialog(this, info);

        ds.disconnect();
    }

    protected void jbInit() throws Exception
    {
        this.setLayout(borderLayout1);

        myContentPane.setBorder(BorderFactory.createEtchedBorder());
        myContentPane.addItem("Database Type", DBType);
        DBType.addItemListener(new DbTypeListListener());

        myContentPane.addItem("DB Machine URL", DBMachineURL);
        myContentPane.addItem("JDBC Driver", jdbcDriver);
        myContentPane.addItem("User ID", UserID);
        myContentPane.addItem("Password", UserPwd);
        myContentPane.setBorder(BorderFactory.createEtchedBorder());

        this.add(myContentPane, java.awt.BorderLayout.CENTER);
        this.add(paneButton, java.awt.BorderLayout.SOUTH);
        paneButton.add(btnTest);

    }
}
